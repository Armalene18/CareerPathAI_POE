using CareerPathAI.API.Data;
using Microsoft.EntityFrameworkCore;
using CareerPathAI.API.Services;

var builder = WebApplication.CreateBuilder(args);

// Add database connection
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")
    )
);

// Add controllers
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAndroid",
        policy => policy
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());
});

builder.Services.AddControllers();
builder.Services.AddScoped<BlobStorageService>();

// Add OpenAPI / Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Enable Swagger during development
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// HTTPS redirection disabled for Android emulator local development
// app.UseHttpsRedirection();

app.UseCors("AllowAndroid");
app.UseAuthorization();

app.MapControllers();

app.Run();