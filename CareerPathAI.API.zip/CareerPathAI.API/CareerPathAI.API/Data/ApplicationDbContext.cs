﻿using CareerPathAI.API.Models;
using Microsoft.EntityFrameworkCore;

namespace CareerPathAI.API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(
            DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    }
}