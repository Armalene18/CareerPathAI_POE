﻿using CareerPathAI.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace CareerPathAI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BlobStorageController : ControllerBase
    {
        private readonly BlobStorageService _blobStorageService;

        public BlobStorageController(
            BlobStorageService blobStorageService)
        {
            _blobStorageService = blobStorageService;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadFile(
            IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("Please select a file.");

            using var stream = file.OpenReadStream();

            string fileUrl =
                await _blobStorageService.UploadFileAsync(
                    stream,
                    file.FileName);

            return Ok(new
            {
                message = "File uploaded successfully.",
                fileName = file.FileName,
                fileUrl = fileUrl
            });
        }
    }
}